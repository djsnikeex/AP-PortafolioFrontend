package com.Portafolio.AdrOn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdrOnApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdrOnApplication.class, args);
	}

}
