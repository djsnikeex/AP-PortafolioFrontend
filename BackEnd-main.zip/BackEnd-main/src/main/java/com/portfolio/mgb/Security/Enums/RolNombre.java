/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.portfolio.mgb.Security.Enums;

/**
 *
 * @author Usuario
 */
public enum RolNombre {
    ROLE_ADMIN, ROLE_USER
}
